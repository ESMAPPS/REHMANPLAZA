(() => {
  "use strict";
  const CFG = window.APP_CONFIG || {firebase:{}, ownerEmail:""};
  const DEMO = !(CFG.firebase && CFG.firebase.apiKey);

  // ---------- Property units ----------
  const I = {
    milk:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M9 2h6v3l2 3v13a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V8l2-3z"/><path d="M7 12h10"/></svg>`,
    cup:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h13v4a6 6 0 0 1-6 6h-1a6 6 0 0 1-6-6z"/><path d="M17 10h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M3 22h16"/></svg>`,
    ball:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3.5 9.5c4 1 13 1 17 0M3.5 14.5c4-1 13-1 17 0M12 3c-2.5 3-2.5 15 0 18"/></svg>`,
    meat:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.5 3.5a5 5 0 0 1 5 5c0 4-5.5 7-8 7l-3 3a2 2 0 1 1-2.5-2.5 2 2 0 1 1 0-3l3-3c0-2.5 3-6.5 5.5-6.5z"/></svg>`,
    check:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`,
    half:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/></svg>`,
    cross:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>`
  };
  const FLOOR = ["گراؤنڈ فلور","پہلی منزل","دوسری منزل"];
  const UNITS = [
    {id:"shop-milk", ur:"دودھ کی دکان", short:"دودھ", sub:"کونے والی دکان", grp:"shops", ic:"milk", en:"Milk Shop"},
    {id:"shop-crockery", ur:"کراکری کی دکان", short:"کراکری", sub:"دکان", grp:"shops", ic:"cup", en:"Crockery"},
    {id:"shop-kids", ur:"بچوں کا پلے ایریا", short:"پلے ایریا", sub:"دکان", grp:"shops", ic:"ball", en:"Kids Play"},
    {id:"shop-meat", ur:"گوشت کی دکان", short:"گوشت", sub:"دکان", grp:"shops", ic:"meat", en:"Meat Shop"},
  ];
  [[10,"پہلی منزل · بائیں"],[11,"پہلی منزل · دائیں"],[12,"دوسری منزل · بائیں"],[13,"دوسری منزل · دائیں"]]
    .forEach(([n, s]) => UNITS.push({id:"flat-"+n, ur:"فلیٹ "+n, short:"فلیٹ "+n, sub:"دکانوں کے اوپر · "+s, grp:"upper", num:n, en:"Flat "+n}));
  for (let h = 1; h <= 3; h++) for (let f = 0; f < 3; f++){
    const n = (h - 1) * 3 + f + 1;
    UNITS.push({id:"flat-"+n, ur:"فلیٹ "+n, short:"فلیٹ "+n, sub:`گھر ${h} · ${FLOOR[f]}`, grp:"h"+h, num:n, en:"Flat "+n});
  }
  const GROUPS = [["shops","سامنے کی دکانیں (مین روڈ)"],["upper","دکانوں کے اوپر فلیٹ"],["h1","گلی · گھر 1"],["h2","گلی · گھر 2"],["h3","گلی · گھر 3"]];
  const byId = Object.fromEntries(UNITS.map(u => [u.id, u]));
  const MUR = ["جنوری","فروری","مارچ","اپریل","مئی","جون","جولائی","اگست","ستمبر","اکتوبر","نومبر","دسمبر"];
  const MEN = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

  // ---------- State ----------
  const now = new Date();
  let cur = {y: now.getFullYear(), m: now.getMonth() + 1};
  const key = (y, m) => `${y}-${String(m).padStart(2, "0")}`;
  let units = {};   // id -> {tenant, rent}
  let pay = {};     // "YYYY-MM" -> id -> {amt, full, at, by}
  let me = {email:"", owner:true};
  let sheetId = null, padMode = null, padVal = "";

  const $ = s => document.querySelector(s);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money = n => Math.round(n || 0).toLocaleString("en-PK");
  const rentOf = id => Number((units[id] || {}).rent) || 0;
  const recOf = (id, y = cur.y, m = cur.m) => (pay[key(y, m)] || {})[id] || null;
  const isFuture = (y, m) => y > now.getFullYear() || (y === now.getFullYear() && m > now.getMonth() + 1);
  function status(id, y, m){
    const r = recOf(id, y, m); if (!r) return "due";
    const rent = rentOf(id), amt = Number(r.amt) || 0;
    if (r.full) return "paid";
    if (rent > 0) return amt >= rent ? "paid" : (amt > 0 ? "part" : "due");
    return amt > 0 ? "paid" : "due";
  }
  const leftOf = (id, y, m) => { const st = status(id, y, m); if (st === "paid") return 0; const r = recOf(id, y, m); return Math.max(0, rentOf(id) - (r ? Number(r.amt) || 0 : 0)); };
  const gotOf = (id, y, m) => { const r = recOf(id, y, m); return r ? Number(r.amt) || 0 : 0; };

  let toastT;
  function toast(t){ const el = $("#toast"); el.textContent = t; el.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("show"), 2200); }

  // ---------- Store (Firebase, or a local demo when not configured) ----------
  const Store = DEMO ? demoStore() : fireStore();

  function demoStore(){
    const read = k => { try { return JSON.parse(localStorage.getItem(k) || "{}"); } catch (e){ return {}; } };
    const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e){} };
    let cbU = () => {}, cbP = () => {};
    return {
      start(onUser){ setTimeout(() => onUser({email:"demo"}), 0); },
      onUnits(cb){ cbU = cb; cb(read("rent.units")); },
      onPay(cb){ cbP = cb; cb(read("rent.pay")); },
      onConnected(){},
      async setPay(k, id, rec){ const p = read("rent.pay"); p[k] = p[k] || {}; if (rec) p[k][id] = rec; else delete p[k][id]; write("rent.pay", p); cbP(p); },
      async setUnits(u){ write("rent.units", u); cbU(u); },
      async login(){ }, async logout(){ toast("ڈیمو"); }
    };
  }

  function fireStore(){
    const F = window.FB;
    const app = F.initializeApp(CFG.firebase);
    const auth = F.initializeAuth(app, {persistence:[F.indexedDBLocalPersistence, F.browserLocalPersistence]});
    const db = F.getDatabase(app);
    let offU = null, offP = null;
    return {
      start(onUser){ F.onAuthStateChanged(auth, u => onUser(u)); },
      onUnits(cb){ if (offU) offU(); offU = F.onValue(F.ref(db, "units"), s => cb(s.val() || {}), () => toast("ڈیٹا نہیں مل سکا")); },
      onPay(cb){ if (offP) offP(); offP = F.onValue(F.ref(db, "pay"), s => cb(s.val() || {}), () => toast("ڈیٹا نہیں مل سکا")); },
      onConnected(cb){ F.onValue(F.ref(db, ".info/connected"), s => cb(!!s.val())); },
      setPay(k, id, rec){ const r = F.ref(db, `pay/${k}/${id}`); return rec ? F.set(r, rec) : F.remove(r); },
      setUnits(u){ return F.set(F.ref(db, "units"), u); },
      login(email, pass){ return F.signInWithEmailAndPassword(auth, email, pass); },
      logout(){ if (offU) offU(); if (offP) offP(); offU = offP = null; return F.signOut(auth); }
    };
  }

  // ---------- Login ----------
  $("#loginForm").addEventListener("submit", async e => {
    e.preventDefault();
    const btn = $("#loginBtn"), err = $("#loginErr");
    btn.disabled = true; btn.textContent = "انتظار کریں…"; err.hidden = true;
    try { await Store.login($("#email").value.trim(), $("#pass").value); }
    catch (x){
      const c = (x && x.code) || "";
      err.textContent = c.includes("network") ? "انٹرنیٹ نہیں ہے۔ انٹرنیٹ آن کر کے دوبارہ کوشش کریں۔"
        : c.includes("too-many") ? "بہت زیادہ کوششیں۔ تھوڑی دیر بعد دوبارہ کریں۔"
        : "ای میل یا پاس ورڈ غلط ہے۔";
      err.hidden = false;
    }
    btn.disabled = false; btn.textContent = "داخل ہوں";
  });
  $("#logoutBtn").addEventListener("click", async () => { await Store.logout(); });

  function onUser(u){
    if (!u){ $("#main").hidden = true; $("#login").hidden = false; return; }
    const owner = !CFG.ownerEmail || (u.email || "").toLowerCase() === CFG.ownerEmail.toLowerCase();
    me = {email: u.email || "", owner};
    $("#login").hidden = true; $("#main").hidden = false;
    $("#settingsBtn").hidden = !owner;
    $("#whoami").textContent = DEMO ? "ڈیمو" : (u.email || "");
    $("#whoami").setAttribute("dir", "ltr");
    Store.onUnits(v => { units = v || {}; renderAll(); });
    Store.onPay(v => { pay = v || {}; renderAll(); });
    Store.onConnected(ok => { $("#offline").hidden = ok; });
    buildMap(); renderAll();
  }

  // ---------- Rendering ----------
  function icHTML(u){ return u.ic ? I[u.ic] : `<b>${u.num}</b>`; }

  function renderSummary(){
    let got = 0, left = 0, paid = 0;
    for (const u of UNITS){ got += gotOf(u.id, cur.y, cur.m); left += leftOf(u.id, cur.y, cur.m); if (status(u.id, cur.y, cur.m) === "paid") paid++; }
    $("#sGot").textContent = "Rs " + money(got);
    $("#sLeft").textContent = "Rs " + money(left);
    $("#sCount").textContent = `${paid} / ${UNITS.length}`;
    $("#sBar").style.width = (paid / UNITS.length * 100).toFixed(1) + "%";
    $("#mlabel").textContent = `${MUR[cur.m - 1]} ${cur.y}`;
    $("#today").hidden = (cur.y === now.getFullYear() && cur.m === now.getMonth() + 1);
  }

  function statusLine(id){
    const st = status(id, cur.y, cur.m), rent = rentOf(id);
    if (st === "paid") return `مل گیا ✓`;
    if (st === "part") return `ملا <span class="num">${money(gotOf(id, cur.y, cur.m))}</span> · باقی <span class="num">${money(leftOf(id, cur.y, cur.m))}</span>`;
    return rent ? `باقی · <span class="num">Rs ${money(rent)}</span>` : `باقی`;
  }

  function renderList(){
    let s = "";
    for (const [g, title] of GROUPS){
      s += `<div class="grp-t">${title}</div><div class="cards">`;
      for (const u of UNITS.filter(x => x.grp === g)){
        const st = status(u.id, cur.y, cur.m), t = (units[u.id] || {}).tenant;
        const mark = st === "paid" ? I.check : st === "part" ? I.half : I.cross;
        s += `<button class="card ${st}" data-open="${u.id}" aria-label="${esc(u.ur)}">
          <span class="ic">${icHTML(u)}</span>
          <span class="nm">${esc(u.short)}${t ? " · " + esc(t) : ""}</span>
          <span class="st">${statusLine(u.id)}</span>
          <span class="mark">${mark}</span>
        </button>`;
      }
      s += `</div>`;
    }
    $("#tab-list").innerHTML = s;
  }

  function renderYear(){
    const y = cur.y;
    let s = `<thead><tr><th class="nm" style="text-align:left">${y}</th>${MEN.map((m, i) => `<th class="${i + 1 === cur.m ? "cur" : ""}">${m}</th>`).join("")}<th>Rs</th></tr></thead><tbody>`;
    const colGot = Array(12).fill(0);
    for (const u of UNITS){
      let tot = 0;
      s += `<tr><td class="nm">${esc(u.en)}</td>`;
      for (let m = 1; m <= 12; m++){
        const st = status(u.id, y, m), g = gotOf(u.id, y, m); tot += g; colGot[m - 1] += g;
        const fut = isFuture(y, m) && st === "due";
        s += `<td class="${m === cur.m ? "cur" : ""}"><span class="dot ${fut ? "fut" : st}">${st === "paid" ? "✓" : st === "part" ? "½" : fut ? "" : "·"}</span></td>`;
      }
      s += `<td class="tot">${money(tot)}</td></tr>`;
    }
    s += `<tr><td class="nm">Total</td>${colGot.map((v, i) => `<td class="tot ${i + 1 === cur.m ? "cur" : ""}" style="font-size:11px">${v ? money(v) : ""}</td>`).join("")}<td class="tot">${money(colGot.reduce((a, b) => a + b, 0))}</td></tr></tbody>`;
    $("#ytable").innerHTML = s;
  }

  function renderMap(){
    $("#map").querySelectorAll(".unit").forEach(g => {
      const st = status(g.dataset.id, cur.y, cur.m);
      g.classList.toggle("is-paid", st === "paid");
      g.classList.toggle("is-part", st === "part");
      g.querySelectorAll("[data-st]").forEach(t => t.textContent = st === "paid" ? "✓" : st === "part" ? "½" : "✗");
    });
  }

  function renderSheet(){
    if (!sheetId) return;
    const u = byId[sheetId], st = status(sheetId, cur.y, cur.m), r = recOf(sheetId), rent = rentOf(sheetId), t = (units[sheetId] || {}).tenant;
    const ic = $("#shIc"); ic.innerHTML = icHTML(u); ic.style.background = `var(--${st === "paid" ? "paid" : st === "part" ? "part" : "due"})`;
    $("#shName").textContent = u.ur;
    $("#shSub").textContent = (t ? t + " · " : "") + u.sub;
    $("#shRent").textContent = rent ? "Rs " + money(rent) : "—";
    const box = $("#shStatus");
    box.className = "sh-status " + st;
    const when = r && r.at ? new Date(r.at) : null;
    const whenTxt = when ? `${when.getDate()} ${MUR[when.getMonth()]}` : "";
    const by = r && r.by && !DEMO ? ` · ${r.by.split("@")[0]}` : "";
    if (st === "paid") box.innerHTML = `${MUR[cur.m - 1]} کا کرایہ مل گیا ✓ <span class="num">Rs ${money(gotOf(sheetId, cur.y, cur.m))}</span><small>${whenTxt}${esc(by)}</small>`;
    else if (st === "part") box.innerHTML = `تھوڑا ملا: <span class="num">Rs ${money(gotOf(sheetId, cur.y, cur.m))}</span> · باقی: <span class="num">Rs ${money(leftOf(sheetId, cur.y, cur.m))}</span><small>${whenTxt}${esc(by)}</small>`;
    else box.innerHTML = `${MUR[cur.m - 1]} کا کرایہ ابھی باقی ہے`;
    const has = !!r;
    $("#shActions").hidden = has || padMode !== null;
    $("#shUndoBox").hidden = !has || padMode !== null;
    $("#shMore").hidden = st !== "part";
    $("#pad").hidden = padMode === null;
    $("#padVal").textContent = money(Number(padVal) || 0);
  }

  function renderAll(){ renderSummary(); renderList(); renderMap(); renderYear(); renderSheet(); }

  // ---------- Sheet actions ----------
  function openSheet(id){ sheetId = id; padMode = null; padVal = ""; $("#backdrop").hidden = false; $("#sheet").hidden = false; renderSheet(); }
  function closeSheet(){ sheetId = null; padMode = null; $("#backdrop").hidden = true; $("#sheet").hidden = true; $("#settings").hidden = true; }
  $("#shClose").addEventListener("click", closeSheet);
  $("#backdrop").addEventListener("click", closeSheet);
  window.onAndroidBack = () => { if (!$("#sheet").hidden || !$("#settings").hidden){ closeSheet(); return true; } return false; };

  async function savePay(id, rec, msg){
    const k = key(cur.y, cur.m), prev = pay[k] && pay[k][id];
    pay[k] = {...(pay[k] || {})};
    if (rec) pay[k][id] = rec; else delete pay[k][id];
    renderAll(); toast(msg);
    try { await Store.setPay(k, id, rec); }
    catch (e){ pay[k] = {...(pay[k] || {})}; if (prev) pay[k][id] = prev; else delete pay[k][id]; renderAll(); toast("محفوظ نہیں ہوا، دوبارہ کوشش کریں"); }
  }
  $("#shFull").addEventListener("click", () => {
    if (!sheetId) return;
    savePay(sheetId, {amt: rentOf(sheetId), full: true, at: Date.now(), by: me.email}, `${byId[sheetId].short}: کرایہ مل گیا ✓`);
  });
  $("#shPart").addEventListener("click", () => { padMode = "new"; padVal = ""; renderSheet(); });
  $("#shMore").addEventListener("click", () => { padMode = "add"; padVal = ""; renderSheet(); });
  $("#shUndo").addEventListener("click", () => { if (sheetId) savePay(sheetId, null, `${byId[sheetId].short}: واپس باقی کر دیا`); });
  document.querySelectorAll(".keys button").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.k;
    if (k === "del") padVal = padVal.slice(0, -1);
    else if (padVal.length < 8) padVal = (padVal + k).replace(/^0+/, "");
    $("#padVal").textContent = money(Number(padVal) || 0);
  }));
  $("#padCancel").addEventListener("click", () => { padMode = null; padVal = ""; renderSheet(); });
  $("#padSave").addEventListener("click", () => {
    const v = Number(padVal) || 0;
    if (!sheetId || v <= 0){ toast("رقم لکھیں"); return; }
    const old = padMode === "add" ? gotOf(sheetId, cur.y, cur.m) : 0, amt = old + v, rent = rentOf(sheetId);
    const full = rent > 0 && amt >= rent;
    padMode = null; padVal = "";
    savePay(sheetId, {amt, full, at: Date.now(), by: me.email}, full ? `${byId[sheetId].short}: پورا کرایہ مل گیا ✓` : `${byId[sheetId].short}: Rs ${money(amt)} ملے`);
  });

  // ---------- Settings (owner) ----------
  $("#settingsBtn").addEventListener("click", () => {
    let s = "";
    for (const u of UNITS){
      const c = units[u.id] || {};
      s += `<div class="set-row"><div class="n">${esc(u.ur)} <span class="muted">${esc(u.sub)}</span></div>
        <input inputmode="numeric" dir="ltr" placeholder="Rs" data-rent="${u.id}" value="${c.rent || ""}" aria-label="${esc(u.ur)} کرایہ">
        <input class="tn" placeholder="کرایہ دار کا نام" data-tn="${u.id}" value="${esc(c.tenant || "")}" aria-label="${esc(u.ur)} کرایہ دار"></div>`;
    }
    $("#setList").innerHTML = s;
    $("#backdrop").hidden = false; $("#settings").hidden = false;
  });
  $("#setClose").addEventListener("click", closeSheet);
  $("#setSave").addEventListener("click", async () => {
    const out = {};
    for (const u of UNITS){
      const rent = Number(String(document.querySelector(`[data-rent="${u.id}"]`).value).replace(/[^\d]/g, "")) || 0;
      const tenant = document.querySelector(`[data-tn="${u.id}"]`).value.trim();
      if (rent || tenant) out[u.id] = {rent, tenant};
    }
    try { await Store.setUnits(out); units = out; closeSheet(); renderAll(); toast("محفوظ ہو گیا"); }
    catch (e){ toast("محفوظ نہیں ہوا"); }
  });

  // ---------- Navigation ----------
  function shift(d){ let m = cur.m + d, y = cur.y; if (m < 1){ m = 12; y--; } if (m > 12){ m = 1; y++; } cur = {y, m}; renderAll(); }
  $("#prev").addEventListener("click", () => shift(-1));
  $("#next").addEventListener("click", () => shift(1));
  $("#today").addEventListener("click", () => { cur = {y: now.getFullYear(), m: now.getMonth() + 1}; renderAll(); });
  document.querySelectorAll("[data-tab]").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll("[data-tab]").forEach(x => x.setAttribute("aria-selected", x === b ? "true" : "false"));
    ["list","map","year"].forEach(t => $("#tab-" + t).hidden = t !== b.dataset.tab);
  }));
  document.addEventListener("click", e => { const o = e.target.closest("[data-open]"); if (o) openSheet(o.dataset.open); });

  // ---------- 3D map ----------
  const K = 6, EX = [0.966, -0.259], EY = [-0.75, -0.45], OXp = 104 * K, OYp = 108 * K;
  const P = (x, y, z) => [OXp + (x * EX[0] + y * EY[0]) * K, OYp + (x * EX[1] + y * EY[1] - z) * K];
  const f1 = v => v.toFixed(1);
  const pts = a => a.map(p => f1(p[0]) + "," + f1(p[1])).join(" ");
  const mat = (a, b, c, d, o) => `matrix(${a.toFixed(3)},${b.toFixed(3)},${c.toFixed(3)},${d.toFixed(3)},${f1(o[0])},${f1(o[1])})`;
  const frontT = (x1, y0, z2) => mat(EX[0]*K, EX[1]*K, 0, K, P(x1, y0, z2));
  const sideT = (x0, y2, z2) => mat(-EY[0]*K, -EY[1]*K, 0, K, P(x0, y2, z2));
  const GAP = 7, SHOP = {x1:12, x2:87, y1:0, y2:24};
  const HOUSES = [1, 2, 3].map((h, i) => ({n:"گھر " + h, ids:[0,1,2].map(f => "flat-" + ((h-1)*3 + f + 1)), x1:12, x2:67, y1:SHOP.y2 + GAP + i * (25 + GAP), y2:SHOP.y2 + GAP + i * (25 + GAP) + 25}));
  const YEND = HOUSES[2].y2 + 8;
  const wall = (cls, w, h, inner) => `<rect class="${cls}" x="0" y="0" width="${w}" height="${h}"/>${inner || ""}<rect class="edge" x="0" y="0" width="${w}" height="${h}"/>`;
  const winRow = (h, xs, ww) => xs.map(u => `<rect class="win" x="${u}" y="${h*0.2}" width="${ww || 3.4}" height="${h*0.42}" rx=".45"/>`).join("");
  const lab = (w, h, t, fs, ur, dx) => `<text class="${ur ? "lblu" : "lbl"}" x="${w/2 + (dx || 0)}" y="${h/2 + fs*0.2}" font-size="${fs}" text-anchor="middle">${esc(t)}</text><text class="lbl" data-st x="${w/2 + (dx || 0)}" y="${h/2 + fs*1.3}" font-size="${(fs*0.7).toFixed(2)}" text-anchor="middle"></text>`;
  function roofBox(b, z){
    const pz = z + 1.2;
    return `<polygon class="roof" points="${pts([P(b.x1,b.y1,z),P(b.x2,b.y1,z),P(b.x2,b.y2,z),P(b.x1,b.y2,z)])}"/>` +
      `<polygon class="parapet" points="${pts([P(b.x1,b.y1,z),P(b.x2,b.y1,z),P(b.x2,b.y1,pz),P(b.x1,b.y1,pz)])}"/>` +
      `<polygon class="parapet" points="${pts([P(b.x1,b.y2,z),P(b.x1,b.y1,z),P(b.x1,b.y1,pz),P(b.x1,b.y2,pz)])}"/>`;
  }
  function tag(x, y, z, t){ const p = P(x, y, z), w = t.length * 13 + 30; return `<g transform="translate(${f1(p[0])},${f1(p[1])})"><rect class="tag-bg" x="${-w/2}" y="-20" width="${w}" height="36" rx="18"/><text class="tag-tx" x="0" y="8" font-size="19" text-anchor="middle">${esc(t)}</text></g>`; }
  const unitG = (id, inner) => `<g class="unit" data-open="${id}">${inner}</g>`;
  function buildMap(){
    let s = `<polygon fill="var(--road)" points="${pts([P(-6,-18,0),P(96,-18,0),P(96,0,0),P(-6,0,0)])}"/>`;
    s += `<g transform="${mat(EX[0]*K, EX[1]*K, -EY[0]*K, -EY[1]*K, P(-6,0,0))}">`;
    for (let i = 3; i < 100; i += 11) s += `<rect x="${i}" y="8.6" width="6" height=".7" fill="var(--road-mark)" opacity=".75"/>`;
    s += `<text class="ground-lbl" x="51" y="15.2" font-size="3.4" text-anchor="middle">MAIN ROAD</text></g>`;
    s += `<polygon fill="var(--plot)" points="${pts([P(12,0,0),P(92,0,0),P(92,YEND,0),P(12,YEND,0)])}"/>`;
    s += `<polygon fill="var(--gali)" points="${pts([P(0,0,0),P(12,0,0),P(12,YEND,0),P(0,YEND,0)])}"/>`;
    s += `<g transform="${mat(-EY[0]*K, -EY[1]*K, -EX[0]*K, -EX[1]*K, P(12,YEND,0))}"><text class="gali-lbl" x="${(YEND - SHOP.y2) / 2 + 2}" y="7.4" font-size="3.2" text-anchor="middle">GALI · 12 FT</text></g>`;
    for (const h of [...HOUSES].reverse()){
      const fh = 10, depth = h.x2 - h.x1;
      h.ids.forEach((id, f) => {
        const z2 = f * fh + fh, n = byId[id].num;
        const side = f === 0
          ? winRow(fh, [1.8]) + `<rect class="wood" x="19.6" y="${fh*0.26}" width="4" height="${fh*0.74}" rx=".5"/>` + lab(25, fh, "Flat " + n, 3, false, -1.2)
          : winRow(fh, [2.2, 19.4]) + lab(25, fh, "Flat " + n, 3);
        s += unitG(id, `<g transform="${frontT(h.x1, h.y1, z2)}">${wall("fa", depth, fh, winRow(fh, [8, 22, 36, 48], 3.6))}</g><g transform="${sideT(h.x1, h.y2, z2)}">${wall("fb", 25, fh, side)}</g>`);
      });
      s += roofBox(h, 30) + tag((h.x1 + h.x2) / 2, (h.y1 + h.y2) / 2, 31, h.n);
    }
    const g1 = 11;
    for (const [id, a, b] of [["shop-milk",12,31],["shop-crockery",31,50],["door",50,56],["shop-kids",56,74],["shop-meat",74,87]]){
      const w = b - a;
      if (id === "door"){ s += `<g transform="${frontT(a, 0, g1)}"><rect x="0" y="0" width="${w}" height="${g1}" fill="var(--parapet)"/><rect class="wood" x="1" y="2.2" width="${w-2}" height="${g1-2.2}" rx=".6"/></g>`; continue; }
      let inner = `<rect x="0" y="0" width="${w}" height="2.4" fill="#000" opacity=".16"/>`;
      for (let v = 3.6; v < g1 - .4; v += 1.3) inner += `<rect x=".8" y="${v}" width="${w-1.6}" height=".2" fill="#fff" opacity=".3"/>`;
      inner += lab(w, g1, byId[id].short, Math.min(3.4, w / 4.2), true);
      let face = `<g transform="${frontT(a, 0, g1)}">${wall("fa", w, g1, inner)}</g>`;
      if (id === "shop-milk") face = `<g transform="${sideT(12, 24, g1)}">${wall("fb", 24, g1, winRow(g1, [5, 15], 4))}</g>` + face;
      s += unitG(id, face);
    }
    s += `<polygon fill="var(--door)" opacity=".55" points="${pts([P(12,0,g1+.1),P(87,0,g1+.1),P(87,-2.2,g1-1),P(12,-2.2,g1-1)])}"/>`;
    const half = 37.5;
    for (const [z1, z2, L, R] of [[11,21,"flat-10","flat-11"],[21,31,"flat-12","flat-13"]]){
      const h = z2 - z1;
      s += unitG(L, `<g transform="${sideT(12, 24, z2)}">${wall("fb", 24, h, winRow(h, [5, 15], 4))}</g><g transform="${frontT(12, 0, z2)}">${wall("fa", half, h, winRow(h, [3, 9, 27, 33]) + lab(half, h, "Flat " + byId[L].num, 3.2))}</g>`);
      s += unitG(R, `<g transform="${frontT(12 + half, 0, z2)}">${wall("fa", half, h, winRow(h, [3, 9, 27, 33]) + lab(half, h, "Flat " + byId[R].num, 3.2))}</g>`);
    }
    s += roofBox(SHOP, 31) + tag(49.5, 12, 32, "دکانیں + فلیٹ");
    $("#map").innerHTML = s;
    renderMap();
  }
  function bbox(b, pad){
    let a = [Infinity, Infinity, -Infinity, -Infinity];
    for (const x of [b.x1, b.x2]) for (const y of [b.y1, b.y2]) for (const z of [0, b.z2]){ const p = P(x, y, z); a = [Math.min(a[0],p[0]), Math.min(a[1],p[1]), Math.max(a[2],p[0]), Math.max(a[3],p[1])]; }
    return [a[0]-pad, a[1]-pad, a[2]-a[0]+pad*2, a[3]-a[1]+pad*2];
  }
  const VIEWS = {all:[0,0,1210,700], shops:bbox({x1:0,x2:92,y1:-8,y2:24,z2:36}, 12), gali:bbox({x1:0,x2:67,y1:HOUSES[0].y1,y2:HOUSES[2].y2,z2:36}, 14)};
  document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll("[data-view]").forEach(x => x.setAttribute("aria-pressed", x === b ? "true" : "false"));
    $("#map").setAttribute("viewBox", VIEWS[b.dataset.view].map(f1).join(" "));
  }));

  // ---------- Start ----------
  Store.start(onUser);
})();
