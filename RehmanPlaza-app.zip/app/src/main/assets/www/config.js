// Firebase project settings (from Firebase console → Project settings → Your apps → Web app).
// These values are not secret; passwords are never stored here.
window.APP_CONFIG = {
  firebase: {
    apiKey: "AIzaSyAxhO4DBtosJcwJsD26pfsOzv7lFeLXWfg",
    authDomain: "rehman-plaza.firebaseapp.com",
    databaseURL: "https://rehman-plaza-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "rehman-plaza",
    storageBucket: "rehman-plaza.firebasestorage.app",
    messagingSenderId: "292235846583",
    appId: "1:292235846583:web:9c3a302b7e58b9e6c67e32"
  },
  // Email of the owner account. Only this account sees the settings (rent amounts, names).
  ownerEmail: "zulfiqarayub@gmail.com"
};
