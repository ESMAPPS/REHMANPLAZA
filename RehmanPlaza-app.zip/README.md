# Rehman Plaza — Rent App

Android app for recording monthly rent of the 4 shops and 13 flats at Rehman Plaza.
Data is shared live between phones through the Firebase project `rehman-plaza`.

- App screens: `app/src/main/assets/www/` (HTML, Urdu interface)
- Firebase settings and owner email: `app/src/main/assets/www/config.js`
- Database rules to paste in Firebase: `database.rules.json`
- The APK is built automatically by GitHub Actions on every upload to `main`
  (`.github/workflows/build-apk.yml`) and published under **Releases** as `RehmanPlaza.apk`.

Keep this repository **private**: it contains the app's signing key (`app/release.jks`).
